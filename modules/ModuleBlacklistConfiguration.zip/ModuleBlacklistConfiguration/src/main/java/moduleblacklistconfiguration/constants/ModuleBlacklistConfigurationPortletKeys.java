package moduleblacklistconfiguration.constants;

/**
 * @author root322
 */
public class ModuleBlacklistConfigurationPortletKeys {

	public static final String MODULEBLACKLISTCONFIGURATION =
		"moduleblacklistconfiguration_ModuleBlacklistConfigurationPortlet";

}