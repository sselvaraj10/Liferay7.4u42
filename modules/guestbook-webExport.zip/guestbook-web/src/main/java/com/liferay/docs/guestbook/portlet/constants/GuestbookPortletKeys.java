package com.liferay.docs.guestbook.portlet.constants;

/**
 * @author root322
 */
public class GuestbookPortletKeys {

	public static final String GUESTBOOK =
		"com_liferay_docs_guestbook_portlet_GuestbookPortlet";

	public static final String GUESTBOOK_ADMIN =
			"com_liferay_docs_guestbook_portlet_GuestbookAdminPortlet";
}