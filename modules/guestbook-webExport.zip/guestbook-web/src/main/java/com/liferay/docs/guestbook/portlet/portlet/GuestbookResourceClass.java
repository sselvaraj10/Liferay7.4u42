package com.liferay.docs.guestbook.portlet.portlet;

import com.liferay.docs.guestbook.portlet.executor.GuestbookEntryBackgroundTaskExecutor;
import com.liferay.docs.guestbook.model.Guestbook;
import com.liferay.docs.guestbook.portlet.constants.GuestbookPortletKeys;
import com.liferay.docs.guestbook.service.GuestbookLocalServiceUtil;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.backgroundtask.BackgroundTask;
import com.liferay.portal.kernel.backgroundtask.BackgroundTaskManagerUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.WebKeys;
import org.osgi.service.component.annotations.Component;

import javax.portlet.*;
import java.io.InputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Component(
        immediate = true,
        property = {
                "javax.portlet.name=" + GuestbookPortletKeys.GUESTBOOK_ADMIN,
               // "mvc.command.name=/export"
        },
        service = MVCResourceCommand.class
)
public class GuestbookResourceClass implements MVCResourceCommand {
    @Override
    public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
        ThemeDisplay themeDisplay  =(ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

        List<Guestbook> guestbookList = GuestbookLocalServiceUtil.getGuestbooks(themeDisplay.getScopeGroupId());

        String[] columnNames = { "UserId","GroupId", "GuestbookId", "Name"};

        final String COMMA = ",";


        StringBundler sb = new StringBundler();

        for (String columnName : columnNames) {

            sb.append(getCSVFormattedValue(columnName));

            sb.append(COMMA);

        }
        sb.setIndex(sb.index() - 1);
        sb.append(CharPool.NEW_LINE);
        for(Guestbook guestbook : guestbookList)
        {
            sb.append(getCSVFormattedValue(String.valueOf(guestbook.getUserId())));
            sb.append(COMMA);
            sb.append(getCSVFormattedValue(String.valueOf(guestbook.getGuestbookId())));
            sb.append(COMMA);
            sb.append(getCSVFormattedValue(String.valueOf(guestbook.getGuestbookId())));
            sb.append(COMMA);
            sb.append(getCSVFormattedValue(guestbook.getName()));
            sb.append(COMMA);

            sb.setIndex(sb.index() - 1);

            sb.append(CharPool.NEW_LINE);
        }



        byte[] bytes = sb.toString().getBytes();
        String contentType = ContentTypes.APPLICATION_TEXT;

        ServiceContext serviceContext = null;
        try {
            serviceContext = ServiceContextFactory.getInstance(
                    Guestbook.class.getName(), resourceRequest);

        Random random = new Random(12);


        Map<String, Serializable> taskContextMap = new HashMap<>();
        taskContextMap.put("processName", "testing " + random.nextInt());
        taskContextMap.put("totalNodes", String.valueOf(random.nextInt()));

            BackgroundTask backgroundTask = BackgroundTaskManagerUtil.addBackgroundTask(themeDisplay.getUserId(),
                    themeDisplay.getScopeGroupId(), GuestbookEntryBackgroundTaskExecutor.class.getName(), GuestbookEntryBackgroundTaskExecutor.class.getName(),taskContextMap, serviceContext);

            resourceRequest.setAttribute("backgroundTaskId",
                    backgroundTask.getBackgroundTaskId());
           // d(resourceRequest,resourceResponse,backgroundTask);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return true;
    }

    protected String getCSVFormattedValue(String value) {
        StringBundler sb = new StringBundler(3);
        sb.append(CharPool.QUOTE);
        sb.append(StringUtil.replace(value, CharPool.QUOTE,
                StringPool.DOUBLE_QUOTE));
        sb.append(CharPool.QUOTE);
        return sb.toString();
    }

    public void d(ResourceRequest resourceRequest, ResourceResponse resourceResponse,BackgroundTask backgroundTask)
    {
        try {
            long backgroundTaskId = backgroundTask.getBackgroundTaskId();
            System.out.println("ids: " + backgroundTaskId);
            BackgroundTask backgroundTask1 = BackgroundTaskManagerUtil.getBackgroundTask(backgroundTaskId);
            System.out.println("BaCKgroundTask Resources: " + backgroundTask1);
            List<FileEntry> fileEntryList = backgroundTask1.getAttachmentsFileEntries();
            System.out.println("files Resources: " + fileEntryList);
            System.out.println("Resources file count: " + backgroundTask1.getAttachmentsFileEntriesCount());

            FileEntry file = fileEntryList.get(0);
            InputStream output = file.getContentStream();

            PortletResponseUtil.sendFile(resourceRequest, resourceResponse, file.getFileName(),
                    output);
        }catch (Exception e) {
            throw new RuntimeException(e);
        }

    }



}
