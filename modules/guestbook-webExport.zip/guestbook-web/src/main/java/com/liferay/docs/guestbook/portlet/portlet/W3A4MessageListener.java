//package com.liferay.docs.guestbook.portlet.portlet;
//
//import com.liferay.portal.kernel.log.Log;
//import com.liferay.portal.kernel.messaging.*;
//import org.osgi.service.component.annotations.Component;
//import com.liferay.portal.kernel.log.LogFactoryUtil;
//import org.osgi.service.component.annotations.Reference;
////import com.liferay.portal.kernel.messaging.sender.SingleDestinationMessageSender;
//@Component(
//        property = "destination.name=" + DestinationNames.LIVE_USERS,
//        service = MessageListener.class
//)
//public class W3A4MessageListener implements MessageListener {
//    @Override
//    public void receive(Message message) throws MessageListenerException {
//        if (_log.isInfoEnabled()) {
//            _log.info("Received message payload " + message.getPayload());
//        }
//    }
//
//    private void sendAsyncMessage (String messageText) {
//
//        Message message = new Message();
//
//        message. setDestinationName (DestinationNames.LIVE_USERS) ;
//
//        message. setPayload(messageText);
//
//        message. setResponseDestinationName (message.getDestinationName());
//
//
//
//        SingleDestinationMessageSender messageSender =
//                _messageSenderFactory. createSingleDestinationMessageSender (message .getDestinationName ())
//
//        messageSender.send(message);
//    }
//
//    @Reference
//        private MessageBus _messageBus;
////    @Reference
////    private SingleDestinationMessageSenderFactory _messageSenderFactory;
//
//    private static final Log _log = LogFactoryUtil.getLog(
//            W3A4MessageListener.class);
//}
