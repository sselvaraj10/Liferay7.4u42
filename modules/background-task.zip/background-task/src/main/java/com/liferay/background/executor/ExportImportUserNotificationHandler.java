package com.liferay.background.executor;

import com.liferay.portal.kernel.model.UserNotificationEvent;
import com.liferay.portal.kernel.notifications.BaseUserNotificationHandler;
import com.liferay.portal.kernel.notifications.UserNotificationHandler;
import com.liferay.portal.kernel.service.ServiceContext;
import org.osgi.service.component.annotations.Component;

@Component(
        immediate = true,
        property = {"javax.portlet.name=" + "BackgroundTaskPortlet"},
        service = UserNotificationHandler.class
)
public class ExportImportUserNotificationHandler extends BaseUserNotificationHandler {


    @Override
    protected String getBody(UserNotificationEvent userNotificationEvent, ServiceContext serviceContext) throws Exception {
        String message = "Message is this";
        System.out.println("aksjkajsajskajska");
        return message;
    }
}
