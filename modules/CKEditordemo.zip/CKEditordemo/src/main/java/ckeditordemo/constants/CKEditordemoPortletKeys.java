package ckeditordemo.constants;

/**
 * @author root322
 */
public class CKEditordemoPortletKeys {

	public static final String CKEDITORDEMO =
		"ckeditordemo_CKEditordemoPortlet";

}